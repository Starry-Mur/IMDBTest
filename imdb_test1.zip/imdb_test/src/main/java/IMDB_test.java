//importing needed packages
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait; posibly needed

public class IMDB_test {

    public static void main(String[] args) {

        //pointing chromedriver location
        System.setProperty("webdriver.chrome.driver","C:\\Users\\User\\IdeaProjects\\imdb_test\\src\\main\\resources\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        //setting start URL
        String baseUrl = "https://www.imdb.com/?ref_=nv_home";

        //opening url
        driver.get(baseUrl);
        //notification whether page opened or not
        if (driver.findElement(By.id("home_img")).isDisplayed()) {
           System.out.println("Page is opened!");
        }
        else {
            System.out.println("Page is closed");
        }
        //searching our film
        WebElement searchBox = driver.findElement(By.name("q"));
        searchBox.sendKeys("Back to the future");
        searchBox.submit();
        //Trying to catch our film. I have some problem with Google Chrome localization.
        //driver.findElement(By.className("findResult odd")).click();
        driver.findElement(By.linkText("Назад в будущее")).click();
        //coping film summary to show in console
        String Summ = driver.findElement(By.className("summary_text")).getText();
        System.out.println(Summ);

        driver.close();

    }
}
